const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '')));

app.post('/api/inventario', (req, res) => {
    const datos = JSON.stringify(req.body, null, 2);
    fs.writeFileSync(path.join(__dirname, 'inventario.json'), datos);
    res.send('Datos guardados');
});

app.listen(PORT, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});